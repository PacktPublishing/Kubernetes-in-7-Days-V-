# Kubernetes in 7 Days - Overview

Welcome to _Kubernetes in 7 Days_.


**Notes**

* The videos are recorded using a Mac.  However the same commands can also be run on Windows and Linux.  The exception being with the helper scripts `kubectx`, `kubens` and `kubetail`, which can only be run on Mac or Linux.
* You can refer to the GitHub repo for _Kubenetes in 7 Days_ to copy the commands from.